from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import asyncio
import os

# Token from Render environment variable
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Default Keywords list
KEYWORDS = ["कर", "payment", "pay", "upi"]

# Payment Reply
PAYMENT_TEXT = """
💳 **Payment Details**
📌 स्कैन करके तुरंत पेमेंट करें 👇

🔗 **UPI ID:** yourupi@bank  
✅ पेमेंट करने के बाद स्क्रीनशॉट भेजें।
"""

# QR Code image path
QR_IMAGE_PATH = "payment_qr.png"

# Default delete time (seconds)
delete_time = 60


# 📌 Keyword Handler
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global delete_time, KEYWORDS
    if not update.message:
        return

    message_text = update.message.text.lower()

    if any(keyword.lower() in message_text for keyword in KEYWORDS):
        # Send QR + text
        sent_message = await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=open(QR_IMAGE_PATH, "rb"),
            caption=PAYMENT_TEXT,
            parse_mode="Markdown"
        )

        # Wait and delete after delete_time
        await asyncio.sleep(delete_time)
        try:
            await context.bot.delete_message(
                chat_id=update.effective_chat.id,
                message_id=sent_message.message_id
            )
        except:
            pass


# 📌 Command: set auto-delete time
async def set_time(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global delete_time
    try:
        new_time = int(context.args[0])
        delete_time = new_time
        await update.message.reply_text(f"✅ Auto-delete time set to {delete_time} seconds.")
    except (IndexError, ValueError):
        await update.message.reply_text("⚠️ Usage: `/settime <seconds>`", parse_mode="Markdown")


# 📌 Command: set keywords
async def set_keywords(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global KEYWORDS
    if not context.args:
        await update.message.reply_text(
            f"⚠️ Usage: `/setkeywords word1 word2 ...`\n\n👉 Current keywords: {', '.join(KEYWORDS)}",
            parse_mode="Markdown"
        )
        return

    KEYWORDS = context.args
    await update.message.reply_text(f"✅ Keywords updated: {', '.join(KEYWORDS)}")


def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("settime", set_time))
    app.add_handler(CommandHandler("setkeywords", set_keywords))

    # Message handler
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Bot is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
